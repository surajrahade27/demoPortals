# Project Setup
You need SVN access to clone the project, You can use tortoise to clone the project or gitbash also work.

# Installation and launching

Installing all the dependencies of project, run following command:

``` npm install ```;

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.


To launch dev project on your local machine run this command:

``` npm start   ```;

To build production build run:

``` npm run build   ```;

This will output build with source maps. To exclude source maps run:

```npm run build:ci```;

# Tests
``` npm run test ```;

This project using basic custome HTML/CSS to create component. At some places MUI component also used.

