import React from 'react';

 function Layout({children}) {
  return (
    <div>
      {children}
    </div>
  )
}
export default Layout;
 
