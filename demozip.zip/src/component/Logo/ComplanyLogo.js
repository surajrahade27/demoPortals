import React from 'react'


function ComplanyLogo({logo}) {
  return (
    <div>
      <div className="login-logo">
        <img src={logo} className="login-logo-media" alt=''/></div>
    </div>
  )
}

export default ComplanyLogo
