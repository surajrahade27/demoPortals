import React from 'react'

function InvalidCode() {
  return (
    <div className="flex-table flex-table-left align-items-center form-field-message ">
												<aside><div className="icon-link icon-link-sm icn-invalid"></div></aside>
												<aside><p className="bold">Invalid code entered</p></aside>
											</div>
  )
}

export default InvalidCode
