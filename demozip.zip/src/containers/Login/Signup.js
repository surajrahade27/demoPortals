import React from 'react'

export default function Signup() {
  return (
    <div>
      <h2> Sign up</h2>
    </div>
  )
}
