import React from 'react'

export default function Template() {
    return (
        <div>
           <img src="https://reactjs.org/logo-og.png" alt="React Logo" />
        </div>
     );
}
