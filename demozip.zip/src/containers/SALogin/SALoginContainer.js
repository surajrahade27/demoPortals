import React from 'react'
import SALogin from './SALogin'

function SALoginContainer() {
  return (
    <div className="app">
      <SALogin />
    </div>
  )
}

export default SALoginContainer
