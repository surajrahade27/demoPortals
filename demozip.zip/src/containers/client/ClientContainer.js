import React from "react";
import AddClient from "../../component/Client/AddClient";
import ManageClient from "../../component/Client/ManageClient";


function ClientContainer(props) {
  return (
    <div>
        <AddClient />
    </div>
  )
}

export default ClientContainer
