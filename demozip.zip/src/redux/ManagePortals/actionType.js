export const GET_PORTALS = 'GET_PORTALS';
export const DELETE_PORTAL = 'DELETE_PORTAL';
export const ADD_PORTAL = 'ADD_PORTAL'
export const GET_PORTAL_BY_ID = 'GET_PORTAL_BY_ID'
export const EDIT_PORTAL = 'EDIT_PORTAL'