export const GET_USERS = 'GET_USERS';
export const DELETE_USER = 'DELETE_USER';
export const ADD_USER = 'ADD_USER'
export const GET_USER_BY_ID = 'GET_USER_BY_ID'
export const EDIT_USER = 'EDIT_USER'